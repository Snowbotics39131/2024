from PortMap24 import *
print("(straight_speed, straight_acceleration, turn_rate, turn_acceleration)")
print(driveBase.settings())
print("(kp, ki, kd, integral_deadzone, integral_rate)")
print("default", driveBase.heading_control.pid())
# defaults to (7558, 0, 1889, 3, 7)
#driveBase.heading_control.pid(1800, 0, 0, 3, 7)
print("testing", driveBase.heading_control.pid())
for _ in range(4):
    driveBase.straight(200)
    driveBase.turn(90)