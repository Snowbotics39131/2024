from PortMap24 import *
#14,1
driveBase.straight(400)
driveBase.turn(-45)
