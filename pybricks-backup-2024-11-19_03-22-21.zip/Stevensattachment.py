from PortMap24 import *

driveBase.straight(190)
driveBase.turn(-45)
driveBase.straight(260)
driveBase.turn(60)
