from pybricks.hubs import InventorHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = InventorHub()

from PortMap24 import *

run_task(multitask(driveBase.straight(300), motorFront.run_angle(-100,500)))
async def parrellel():
    await multitask(driveBase.straight(-300), motorFront.run_angle(100,500)))


# run_task(parrellel())