from PortMap24 import *

mission = hub_menu(1,2,3,4,5)
print(mission)

if mission == 1:
    import mission1_2024
if mission == 2:
    import mission3_2024
if mission == 3:
    import mission2_2024
#if mission == 4:
   # import 
if mission == 4:
    import rightmap
if mission == 5:
    import go
if mission == 6:
    import whaleandkrill