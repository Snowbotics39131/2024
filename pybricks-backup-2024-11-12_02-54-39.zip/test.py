from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
 
from PortMap import*

driveBase.straight(1000
driveBase.straight(-200)
driveBase.turn(-90)
driveBase.straight(-200)
driveBase.turn(-50)
driveBase.straight(500)
driveBase.straight(-200)
driveBase.turn(45)
driveBase.straight(1000)
driveBase.turn(-35)
driveBase.straight(-100)
drivebase.turn(30)
driveBase.straight(-4000)


